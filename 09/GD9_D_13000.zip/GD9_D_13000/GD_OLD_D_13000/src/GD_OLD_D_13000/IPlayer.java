/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package GD_OLD_D_13000;

/**
 *
 * @author farel
 */
public interface IPlayer {
    public void mainTournament();
}
