/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package control;

import java.util.List;
import model.KasirE;

/**
 *
 * @author farel
 */
public class KasirControlE extends KasirControl {
    private KasirControlE kaoe = new KasirControlE();
    public List<KasirE> showListKasir() {
        return kaoe.showListKasir();
    }
}
