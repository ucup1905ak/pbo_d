
package latsolnetbeans_d_13000;

public class LatsolNetbeans_D_13000 {
    public static void main(String[] args) {
        
        String namaLengkap  = "Farelino Alexander Kim";
        int npm             = 240713000;
        char kelasPbo       = 'D';  
        String hobi         = "Coding";
        String asalKota     = "Tasikmalaya";
        
        System.out.println("Halo semuanya, perkenalkan nama aku "+namaLengkap+" dengan NPM "+npm+" dari Kelas PBO "+kelasPbo+
                ".\nAku punya hobi "+hobi+" dan asal kotaku dari "+asalKota+". Salam kenal semuanya!!");
        
        for(int i = 1 ; i <= 6;i++)
            System.out.println(i+". Aku Siap menghadapi PBO!");
        
    }  
}
