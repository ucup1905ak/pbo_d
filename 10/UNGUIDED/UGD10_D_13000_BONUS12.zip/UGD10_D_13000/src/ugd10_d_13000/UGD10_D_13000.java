/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ugd10_d_13000;

/**
 *
 * @author Farelino Alexander Kim - 2140713000
 */
public class UGD10_D_13000 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
            MarkasBesar markasTNI = new MarkasBesar("Markas Besar TNI", 1945, 50000000);
            Komandan Dio = new Komandan(8, "Jenderal Dio", 10000000, markasTNI);

            markasTNI.setKomandanUtama(Dio);

            Komandan michael = new Komandan(3, "Kolonel Michael", 7000000, markasTNI);
            Komandan tosi = new Komandan(6, "Mayor Tosi", 8000000, markasTNI);
            Dio.rekrutPasukan(michael);
            Dio.rekrutPasukan(tosi);

            Prajurit p1 = new Prajurit("Infanteri", "Rina", 3500000, markasTNI);
            Prajurit p2 = new Prajurit("Artileri", "Doni", 3500000, markasTNI);
            Prajurit p3 = new Prajurit("Infanteri", "Kartika", 3500000, markasTNI);
            Prajurit p4 = new Prajurit("Artileri", "Hendra", 3500000, markasTNI);

            michael.rekrutPasukan(p1);
            michael.rekrutPasukan(p2);
            tosi.rekrutPasukan(p3);
            tosi.rekrutPasukan(p4);

            markasTNI.TampilStrukturKomando();

            System.out.println("\nTampilan setelah menerima anggaran operasional sebesar 1000000");
            markasTNI.terimaAnggaranOperasional(1000000);

            System.out.println("\n\tSetelah Menerima Anggaran Operasional...\n");
            markasTNI.TampilStrukturKomando();

        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }

}
